package com.talk2amareswaran.projects.socialloginapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialLoginAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocialLoginAppApplication.class, args);
	}
}
