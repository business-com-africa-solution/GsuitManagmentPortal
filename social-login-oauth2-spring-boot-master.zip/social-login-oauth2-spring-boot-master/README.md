# social-login-oauth2-spring-boot

Hello Everyone,

Here is the video of Social Login with OAuth2 in Spring Boot

Video link - https://youtu.be/iwr047lAcO0

Please subscribe my youtube channel - https://www.youtube.com/c/Talk2Amareswaran

Please like my Facebook page - https://facebook.com/talk2amareswaran

Please join my Facebook group - https://www.facebook.com/groups/271796230307847/
